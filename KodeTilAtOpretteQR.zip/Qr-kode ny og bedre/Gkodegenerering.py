def read_qr_code_txt(file_path):   #  Opsplitter qr koden i en liste, der indeholder hver raekke som en string per indgang
    # Laes indholdet af filen
    with open(file_path, 'r') as file:
        content = file.read()

    # Opdel indholdet i raekker
    rows = content.strip().split('\n')

    return rows


def count_consecutive_values(data):   #Den taeller antallet af ens karakterer i raekkerne
    count = 1  # Begynd at taelle fra 1, da det foerste vaerdi altid "gentages" mindst én gang.
    current_value = data[0]  # Saet den aktuelle vaerdi til det foerste tegn i strengen.

    for char in data[1:]:
        if char == current_value:
            count += 1  # Inkrementer taelleren, hvis det nuvaerende tegn er det samme som det foregaaende.
        else:
            break  # Afslut loekken, naar en ny vaerdi stoedes paa.

    return count

def process_qr_code_list(qr_code_list):  #  Bruger count_consecutive_values til at lave en tuple for hver string, der indeholder values og repetetions
    result = []

    for data_streng in qr_code_list:
        values = []
        repetitions = []

        while data_streng:
            count = count_consecutive_values(data_streng)
            values.append(data_streng[0])
            repetitions.append(count)
            data_streng = data_streng[count:]  # Skaer den allerede taellede del af strengen af

        result.append((values, repetitions))

    return result

def generate_gcode_for_row(values, repetitions, current_x, current_y, h, left_to_right): #G-kode genereringsfunktion til alle itterationer udover, hvor vertikallinjen genereres
    gcode_commands = []

    if not left_to_right: #tager hoejde for at hver anden raekke skal reverse engraveres.
        values = reversed(list(reversed(values)))
        repetitions = reversed(list(reversed(repetitions)))
    for value, repetition in zip(values, repetitions):
        # Tjek, om indgraveringens retning er fra venstre mod hoejre.
        if left_to_right:
            current_x -= h * repetition
        else:
            current_x += h * repetition
        
        # Tjek, om vaerdien er meget lille, og rund den ned til nul.
        current_x = 0 if abs(current_x) < 1e-10 else current_x
        current_y = 0 if abs(current_y) < 1e-10 else current_y
        
         # Tilfoej M106- eller M107-kommandoer baseret paa vaerdien.
        if value == '1':
            gcode_commands.append(f"G01 X{current_x} Y{current_y} M106")
        elif value == '0':
            gcode_commands.append(f"G01 X{current_x} Y{current_y} M107")
    
    return gcode_commands

def add_ncodes_to_gcode_file(input_file_path): #Funktion til at tilfoeje Nkoder til starten af alle linjer i G-koden
    # Laes indholdet af filen.
    with open(input_file_path, 'r') as file:
        content = file.readlines()

    # aendr hver linje for at tilfoeje N-koder.
    modified_content = []
    for i, line in enumerate(content, start=1):
        # Tilfoej N-kode. 
        n_code = f'N{i:02d}'
        modified_line = f"{n_code} {line.strip()}\n"

        # Tilfoej den aendrede linje til listen.
        modified_content.append(modified_line)

    # Skriv det aendrede indhold tilbage til filen.
    with open(input_file_path, 'w') as file:
        file.writelines(modified_content)
file_path = 'output4.txt'
input_file_path = 'output.gcode'
qr_code_list = read_qr_code_txt(file_path)
rows_data  = process_qr_code_list(qr_code_list)
side_length = 60   #mm
F = 5000           #Feedrate
k = len(read_qr_code_txt(file_path)[0].strip())   # Antal tal i en raekke.
h = side_length / k
i = 0
current_x = 0 
current_y = 0
# Generer G-kode for hver raekke og gem det i en fil.
values_list, repetitions_list = zip(*rows_data)
output_file_path = 'output.gcode'
with open(output_file_path, 'w') as gcode_file:
    gcode_file.write(f"G01 X{current_x} Y{current_y} F{5000}\n")
# Flag til at bestemme indgraveringens retning (venstre mod hoejre eller hoejre mod venstre).
left_to_right = True

# Gennemloeb hver raekkes data og generer G-kode.
for values, repetitions in zip(values_list, repetitions_list):
    # Tjek, om vi skal skifte indgraveringens retning.
    if left_to_right:
        current_x = 0
        left_to_right = False
    else:
        current_x = side_length
        left_to_right = True

    # Generer G-kode for den aktuelle raekke.
    gcode_commands_for_row = generate_gcode_for_row(values, repetitions, current_x, current_y, h, left_to_right)

    # Tilfoej de genererede G-kodekommandoer til outputfilen.
    with open(output_file_path, 'a') as gcode_file:
        gcode_file.write("\n".join(gcode_commands_for_row) + "\n")
        # Tjek, om betingelsen er sand, og goer ingenting, hvis det er tilfaeldet.
        if current_y + h > side_length:
            pass
        else:
            # Tilfoej den lodrette linje ved slutningen af den aktuelle raekke.
            gcode_file.write(f"G01 X{side_length if not left_to_right else 0} Y{current_y+h} M107\n")
            

    # Opdater den aktuelle position til den naeste raekke.
    current_y += h


add_ncodes_to_gcode_file(input_file_path)
    
    










